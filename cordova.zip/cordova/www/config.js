let VUE_CONFIG = {
    api: "http://47.92.68.45:18080/a39b1f62-afb4-11ea-9711-08d23ee9ec19",
    api2: "http://47.92.68.45:18080"

}

window.VUE_CONFIG = VUE_CONFIG;